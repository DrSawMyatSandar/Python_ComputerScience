# Q03c

# -----------------------------------------------------
# Write your code below this line
