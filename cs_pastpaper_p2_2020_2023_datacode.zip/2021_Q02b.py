# Q02(b)

# Initialise variables
booksSold = 0
profit = 0

booksSold = int(input("Enter the number of books sold: "))
profit = int(input("Enter the profit made: "))

# Add your code
if : 
    print("Poor performance this week")
elif : 
    print("Sales and profit are excellent this week")
elif : 
    print("Sales and profit are good this week")
else:
