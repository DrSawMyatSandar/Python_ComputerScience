#initialise variable

username="bard423"
password="nX2934?"

inputUserName=input("Enter user name:")
inputPassword=input("Enter Password:")

if inputUserName==username and inputPassword==password:
    print("Welcome")
else:
    print("Error")