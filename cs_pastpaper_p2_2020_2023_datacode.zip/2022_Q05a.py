# Q05(a)
alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; # Valid uppercase letters in the alphabet
digit = "0123456789"; # Valid digits
passwordFile = open("passwords.txt", "r") # Open the file password.txt to read
# Add your code here
