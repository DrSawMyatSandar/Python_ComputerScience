# Q03c

# Complete the line to take a string input
aString = 

# Complete the selection statement
 (aString != ""):

    # Convert the string to an integer
    aNum = 

    if (aNum > 0):
    
        # Complete the test
        if (          )       (          ):
            print ("Acceptable")
        # Complete the test            
        elif (           )       (         ):
            print ("Centre")
        # Complete the test            
        elif (          ):
            print ("Perfect")
        else:
            print ("No message")
    else:
        print ("The number must be greater than zero")
else:
    print ("You must provide a number")



 
    