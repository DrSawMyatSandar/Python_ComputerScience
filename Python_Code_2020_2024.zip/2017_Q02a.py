# Print prompt and take country from user

# Tell the user their country

# Take number of adults in party from user

# Take number of children in party from user

# Calculate total number in party

# Tell the user the total number of people in their party

