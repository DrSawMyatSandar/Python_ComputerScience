# Q01f
length = float(input("Enter the length of a side ")
area == length * length
print("The area of the square is,area")