# Q01c

count = 0
total = 0
subTotal = 0

# Loop for 50 times
while (count < 50):
    total = total + count

    if ((count > 10) and (count < 20)):
        subTotal = subTotal + count

    count = count + 1

print (total, subTotal)



