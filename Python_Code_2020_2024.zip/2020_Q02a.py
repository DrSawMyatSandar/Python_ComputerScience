#Q02a

#Initalise variables


#Print prompt and take input

#Calcuate area and print out values
        
