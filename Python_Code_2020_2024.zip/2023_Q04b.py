# Q04b

# ---------------------------------------------------------
# Write your code below this line
word=input("Enter a word:")