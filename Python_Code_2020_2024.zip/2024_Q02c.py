# Q02c

import random

width = 0
length = ;4
perimeter = 0

width = random.randint (1 5)
perimeter = (2 % width) + (2 * length)

print (width, length, perimeter)

