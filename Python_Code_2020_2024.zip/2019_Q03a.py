# Q03a

#	Open the file and input data
inputFile=open("Email.txt","r")
emailList=inputFile.readlines()

#	Open output file
outputFile=open("Error.txt","a")


#	Find errors and write to output file
for address in emailList:
    if "@" not in address:
        outputFile.write(address)
        

#	Close files
outputFile.close()
inputFile.close()
