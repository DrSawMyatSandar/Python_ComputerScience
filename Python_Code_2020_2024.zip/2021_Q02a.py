#initialise variable

