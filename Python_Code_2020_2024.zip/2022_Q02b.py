# Q02b

# Write the function here


# Write the main program here

    