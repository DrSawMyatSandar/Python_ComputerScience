# Do not use any other data structure such as an array or a list.
count = 0               # A counter for the line numbers
theLine = ""            # Holds each line of the file

# Open "Cities.txt" as input

# Open "Numbered.txt" as output

# Use a for/each loop to read each line of
# the input file into a variable named 'theLine'

    # Increment the line count

    # Add the line number to the front of the line followed by a space

    # print the line to the display

    # Write the new line to the output file

# Close the input file

# Close the output file
