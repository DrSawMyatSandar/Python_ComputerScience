# Q03b

starNames = ["Alasia", "Beid", "Castor", "Denebola",
                "Electra", "Fafnir", "Gudja", "Haedus",
                "Izar", "Jishui", "Kang", "Lich", 
                "Maia", "Nahn", "Ogma", "Peacock"]

# Write your code here


    
    
