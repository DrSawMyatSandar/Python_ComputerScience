#ch19_c2
initial_rabbit_population = 50
initial_fox_population = 10

growth_rate = 0.05
interaction_coefficient = 0.0002

for iteration in range(10):
    change_rabbit = growth_rate * initial_rabbit_population - interaction_coefficient * initial_fox_population * initial_rabbit_population
    new_rabbit_population = initial_rabbit_population + change_rabbit
    
    print(f"Iteration {iteration + 1}: Rabbit Population = {new_rabbit_population:.2f}")
    initial_rabbit_population = new_rabbit_population
    
    print(f"Final Rabbit Population: {new_rabbit_population:.2f}")