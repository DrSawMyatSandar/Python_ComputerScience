#ch1_act6
existing_usernames = ['user1','pw1']
while True:
    username = input("Enter your username: ")
    if username in existing_usernames:
        break
    else:
        print("Username not found. Please try again.")
while True:
    password = input("Enter your password: ")
    if password in existing_usernames:
        break
    else:
        print("Incorrect password. Please try again.")
print("Login success")