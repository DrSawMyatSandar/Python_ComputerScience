#u1-7
parcel = "y"
while parcel.lower() == "y":
    weight = int(input("Enter the parcel weight (in kg):"))
    if weight <= 2:
        cost = 3
    else:
        if weight > 10:
            cost = 3 + (8 * 2) + ((weight - 10) * 3)
        else:
            cost = 3 + ((weight - 2) * 2)
    print("Delivery cost:", cost)
    
    parcel=input('Press "y" to process another parcel.')

print('Parcel processing complete')

    