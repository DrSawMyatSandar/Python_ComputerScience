#ch19_act20

gender=input("Enter gender (male or female):")
subject=input("Enter subject (cs or physics)")

if gender=='female' and (subject=='cs' or subject=='physics'):
    print("Superstar:")
