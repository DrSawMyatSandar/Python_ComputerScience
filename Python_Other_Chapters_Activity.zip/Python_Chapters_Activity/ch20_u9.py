#ch20_u9
standard_price = 5  
age = int(input("Enter your age:"))

if age < 4:
    price = 0
else:
    if age < 16 or age > 65:
        price = standard_price / 2
    else:
        price = standard_price
print(f"The calculated price is: {price}")
