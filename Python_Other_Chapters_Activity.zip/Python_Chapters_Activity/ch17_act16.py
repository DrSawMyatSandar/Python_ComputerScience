#ch17_act16

import time
from time import sleep
start='n'
while start!='y':
    start=input("Press y to start:")
    for sequence in range(12):
        light=['red','green','amber'][sequence%3]
    
        print(light)
        time.sleep(1.5)


