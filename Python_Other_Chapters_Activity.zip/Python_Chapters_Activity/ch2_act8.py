#ch2_act8
testScore = float(input("Enter the test score: "))
if testScore >= 80:
    grade = 'A'
elif testScore >= 70:
    grade = 'B'
elif testScore >= 60:
    grade = 'C'
elif testScore > 0:
    grade = 'D'
else:
    grade = 'FAIL'
print("Grade:", grade)
