#ch2_c2
current_day=int(input("Enter day (0 to 6 (eg,0 is Monday:)"))
current_hour = int(input("Enter hour (0 to 24):"))

if 0 <= current_day <= 4: # Monday to Friday
    if (6 <= current_hour <= 8.5) or (17.5 <= current_hour <= 22):
        temperature=20
    else:
        temperature=None
else:
    if 8 <= current_hour <= 23:
        temperature=22
    else:  
        temperature=None

if temperature is not None and temperature < 10:
    print("Boiler switched on!")
    
if temperature is not None:
    print(f"Temperature adjusted to {temperature}°C")
