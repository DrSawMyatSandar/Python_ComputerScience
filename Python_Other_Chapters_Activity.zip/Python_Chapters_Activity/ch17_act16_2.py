#ch17_act16_2
attempts = 0
while attempts < 3:
    pin = int(input("Enter PIN:"))
    
    if pin == 111:
        print("Approve Payment")
        break
    else:
        attempts+=1
        print(f"Incorrect PIN. {3 - attempts} attempts remaining.")
if attempts==3:
    print("Lock Card")