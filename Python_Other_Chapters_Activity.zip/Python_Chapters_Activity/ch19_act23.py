#ch19_act23
import random
first_roll=random.randint(1,6)
print(first_roll)
