#ch18_s2

sensor_reading = input("Enter sensor reading (dark or light): ").lower()
headlamp_switch = input("Is the headlamp switch on? (yes or no): ").lower()
if sensor_reading == "dark" or headlamp_switch == "on":
    print("Sending switch-on signal to headlamps")
else:
    print("No signal")
