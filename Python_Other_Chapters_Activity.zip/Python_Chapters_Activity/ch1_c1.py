#ch1-c1
height = float(input("Enter your height (in inches):"))
weight = float(input("Enter your weight (in lb):"))
bmi = 703*weight / (height ** 2)
print("Your BMI is:", bmi)