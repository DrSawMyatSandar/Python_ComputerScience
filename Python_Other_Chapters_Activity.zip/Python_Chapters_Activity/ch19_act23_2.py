#ch19_act23_2
import random
first_roll=random.randint(1,7)

if first_roll>=6:
    print(6)
    print(first_roll,6)
else:
    print(first_roll)
