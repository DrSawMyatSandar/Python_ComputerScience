#ch15_act18
LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
def encrypt(message,key):#H
    encrypted=""
    for chars in message:
        if chars in LETTERS:
            num=LETTERS.find(chars)#find -show index - 7
            num+=key
            encrypted+=LETTERS[num]#K
    return encrypted           
        

def decrypt(message,key):#K
    decrypted=""
    for chars in message:
        if chars in LETTERS:
            num=LETTERS.find(chars)#find -show index - 10
            num-=key
            decrypted+=LETTERS[num]#H
    return decrypted           

def main():
    message=input("Enter your message:")
    key=int(input("Enter your key 1-26:"))
    choice=input("Encrypt or Decrypt (e or d):")
    if choice.lower().startswith('e'):
        print(encrypt(message,key))
    else:
        print(decrypt(message,key))
        
main()  

    